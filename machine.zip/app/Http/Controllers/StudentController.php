<?php

namespace App\Http\Controllers;

use App\Models\Student;
use App\Models\Country;
use App\Http\Requests\StoreStudentRequest;
use App\Http\Requests\UpdateStudentRequest;
use Illuminate\Http\Request;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $students = Student::paginate(25);

        foreach ($students as $key => $student) {
            $students[$key]->state = $student->state;
            $students[$key]->country = $student->country;
        }

        return view('students', [ 'students' => $students, 'header' => 'Students List', 'desc' => 'You can view all students List here']);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $countries = Country::all();
        foreach ($countries as $key => $country) {
            $countries[$key]->states = $country->states;
        }
        return view('add-students', [ 'countries' => $countries->toJson(), 'header' => 'Add Students', 'desc' => 'You can add more students here!']);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreStudentRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        for ($i=1; $i < 26; $i++) {
            if ($request->{'name'.$i}) {
                $request->validate([
                    ['name'.$i => 'required|string|max:255'],
                    ['image'.$i => 'required|image|max:2048'],
                    ['country_id'.$i => 'required|numeric|exists:countries'],
                    ['state_id'.$i => 'required|numeric|exists:states'],
                ]);
                $path = $request->file('image'.$i)->store('public/img');

                $student = new Student;
                $student->name = $request->{'name'.$i};
                $student->image = $path;
                $student->country_id = $request->{'country_id'.$i};
                $student->state_id = $request->{'state_id'.$i};
                $student->save();
            } else {
                if ($i == 1) {
                    return back()->with(['message' => 'Please Fill Any!', 'type' => 'error']);
                }
                break;
            }
        }

        return back()->with('message', 'Students Added Successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function show(Student $student)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function edit(Student $student)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateStudentRequest  $request
     * @param  \App\Models\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateStudentRequest $request, Student $student)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function destroy(Student $student)
    {
        //
    }
}
