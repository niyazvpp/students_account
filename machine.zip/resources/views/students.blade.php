@extends('layouts.dash')

@section('main')

<div class="px-8 py-4 my-6">
   <div class="w-full">

        @php

        $headers = ['Id', 'Name', 'Country', 'State', 'Image'];
        $body = [];
        foreach ($students as $student) {
            $body[] = [
                $student->id,
                $student->name,
                $student->country->name,
                $student->state->name,
                "<img src='" . asset(str_replace("public/","storage/",$student->image)) . "' class='w-8 h-8'>"
            ];
        }

        @endphp

        <div class="card">
            <div class="card-body">
                <x-table :headers="$headers" :body="$body" />
            </div>
        </div>

   </div>  
</div>

@endsection