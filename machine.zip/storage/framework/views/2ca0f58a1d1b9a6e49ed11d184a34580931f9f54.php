<table class="min-w-max w-full table-auto">
   <thead>
       <tr class="text-gray-400 font-light text-sm leading-normal">
           <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th class="font-normal text-left pr-3"><?php echo e($header); ?></th>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </tr>
   </thead>
   <tbody class="text-gray-300 text-sm font-light">
        <?php $__currentLoopData = $body; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-b border-gray-100">
                <?php $__currentLoopData = $tr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $td): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td class="py-3 pr-3 text-left text-gray-700"><?php echo $td; ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </tbody>
</table><?php /**PATH C:\xampp\htdocs\machine\example-app\resources\views/components/table.blade.php ENDPATH**/ ?>