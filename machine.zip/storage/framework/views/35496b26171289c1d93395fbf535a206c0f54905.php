

<?php $__env->startSection('main'); ?>

<div class="px-8 py-4 my-6" x-data='{ count: 1, countries: <?php echo $countries; ?>, countryselected: {}, states(c) {
    
    if (this.countryselected["c" + c]) return this.countries[this.countryselected["c" + c]-1].states;
    return [];
}, stateselected: {} }'>
   <div class="w-full">

        <div class="card">
            <div class="card-body">
                
                <div>
                    <div class="py-2 text-right">
                        <button @click="count < 25 && count++" class="btn btn-blue px-8">Add +</button>
                    </div>
                    <div class="grid grid-cols-12 space-4 py-4">
                        <div class="text-gray-400 font-medium col-span-1 text-center">
                            Id
                        </div>
                        <div class="text-gray-400 font-medium col-span-3">
                            Name
                        </div>
                        <div class="text-gray-400 font-medium col-span-2 text-center">
                            Country
                        </div>
                        <div class="text-gray-400 font-medium col-span-3 text-center">
                            State
                        </div>
                        <div class="text-gray-400 font-medium col-span-3 text-center">
                            Image
                        </div>
                    </div>
                    <form action="<?php echo e(route('addStudents')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                        <template x-for="c in count">
                            <div class="grid grid-cols-12 space-4 border-b text-gray-800 py-4">
                                <div class="font-medium pr-2 col-span-1 text-center" x-text="c">
                                    Id
                                </div>
                                <div class="font-medium pr-2 col-span-3">
                                    <input type="text" class="input" :name="'name'+c">
                                </div>
                                <div class="font-medium pr-2 col-span-2 text-center">
                                    <select @change="countryselected['c' + c] = $event.target.value; console.log(JSON.stringify(countryselected))" class="input" :name="'country_id'+c">
                                        <option value="">-- Select Country --</option>
                                        <template x-for="(country, cc) in countries" :key="country.id">
                                            <option :value="country.id" x-text="country.name"></option>
                                        </template>
                                    </select>
                                </div>
                                <div class="font-medium pr-2 col-span-3 text-center">
                                    <select @change="stateselected['c'] = $event.target.value; console.log(stateselected)" class="input" :name="'state_id'+c">
                                        <option value="">-- Select State --</option>
                                        <template x-for="(state, ss) in states(c)" :key="state.id">
                                            <option :selected="stateselected['c' + c] == state.id" :value="state.id" x-text="state.name"></option>
                                        </template>
                                    </select>
                                </div>
                                <div class="font-medium pr-2 col-span-3 text-center">
                                    <input type="file" :name="'image'+c" class="input" accept="image/*">
                                </div>
                            </div>
                        </template>
                        <div class="py-2 text-right">
                            <button type="submit" class="btn btn-green px-10 mr-2">Add Students</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>

   </div>  
</div>
<?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\machine\example-app\resources\views/add-students.blade.php ENDPATH**/ ?>