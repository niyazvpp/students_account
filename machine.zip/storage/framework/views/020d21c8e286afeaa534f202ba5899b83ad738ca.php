

<?php $__env->startSection('main'); ?>

<div class="px-8 py-4 my-6">
   <div class="w-full">

        <?php

        $headers = ['Id', 'Name', 'Country', 'State', 'Image'];
        $body = [];
        foreach ($students as $student) {
            $body[] = [
                $student->id,
                $student->name,
                $student->country->name,
                $student->state->name,
                "<img src='" . asset(str_replace("public/","storage/",$student->image)) . "' class='w-8 h-8'>"
            ];
        }

        ?>

        <div class="card">
            <div class="card-body">
                <?php if (isset($component)) { $__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Table::class, ['headers' => $headers,'body' => $body]); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6)): ?>
<?php $component = $__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6; ?>
<?php unset($__componentOriginale53a9d2e6d6c51019138cc2fcd3ba8ac893391c6); ?>
<?php endif; ?>
            </div>
        </div>

   </div>  
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\machine\example-app\resources\views/students.blade.php ENDPATH**/ ?>