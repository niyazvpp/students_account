

<?php $__env->startSection('main'); ?>
<div x-cloak class="flex flex-col items-center justify-center bg-gray-100 px-4 py-12" x-data="dataTo()" x-init="()=> { $nextTick(()=> { setVariants(); }) }">

<form @submit.prevent="submit($event)" enctype="multipart/form-data" action="<?php echo e(request()->routeIs('products.create') ? route('products.store') : ''); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="container w-full lg:w-5/6">
        <div class="md:grid md:grid-cols-3 md:gap-6">
            <div class="md:col-span-1">
              <div class="px-4 sm:px-0">
                <h3 class="text-lg font-medium leading-6 text-gray-900">Prodcut Details</h3>
                <p class="mt-1 text-sm text-gray-600">Please provide correct information as per documents to avoid mismatches.</p>
              </div>
            </div>
            
            <div class="mt-5 md:mt-0 md:col-span-2">
                <div class="shadow overflow-hidden sm:rounded-md">
                  <div class="px-4 py-5 bg-white sm:p-6">
                    <div class="grid grid-cols-6 gap-6">
                      <div class="col-span-6 form-wrapper">
                        <label for="title" class="block text-sm font-medium text-gray-700">Product Title</label>
                        <input type="text" <?php if(isset($product)): ?>
                        value="<?php echo e($product->title); ?>"
                        <?php endif; ?> name="title" id="title" autocomplete="title" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                      </div>

                      <div class="col-span-6 form-wrapper">
                          <label class="block text-sm font-medium text-gray-700"> Product Image </label>
                          <div class="mt-1 flex items-center">
                            <span class="inline-block h-16 w-16 rounded-full overflow-hidden bg-gray-100">
                              <svg x-show="!image && !ogImage" class="h-full w-full text-gray-300" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M24 20.993V24H0v-2.996A14.977 14.977 0 0112.004 15c4.904 0 9.26 2.354 11.996 5.993zM16.002 8.999a4 4 0 11-8 0 4 4 0 018 0z" />
                              </svg>
                              <img :src="image || ogImage" x-show="image || ogImage" class="h-full w-full object-cover">
                            </span>
                            <label for="image" class="ml-5 bg-white py-2 px-3 border border-gray-300 rounded-md shadow-sm text-sm leading-4 font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 cursor-pointer">
                                <input type="file" id="image" name="image" accept="image/jpg, image/jpeg, image/png" class="hidden" @change="imageChange($event)" />
                                <span x-text="image || ogImage ? 'Change' : 'Select Photo'"></span>
                            </label>
                          </div>
                          <p class="mt-2 text-sm text-gray-500">Product Image - Max size 2048</p>
                        </div>

                      <div class="col-span-6 form-wrapper">
                          <label for="description" class="block text-sm font-medium text-gray-700"> Description </label>
                          <div class="mt-1">
                            <textarea id="description" name="description" rows="3" class="shadow-sm focus:ring-blue-500 focus:border-blue-500 mt-1 block w-full sm:text-sm border border-gray-300 rounded-md" placeholder="description"><?php if(isset($product)): ?>
                        <?php echo e($product->description); ?>

                        <?php endif; ?></textarea>
                          </div>
                          <p class="mt-2 text-sm text-gray-500">Brief description for your product.</p>
                        </div>

                      <template x-for="i in count">
                          <div class="col-span-6 form-wrapper sm:grid sm:grid-cols-2 gap-2">
                              
                              <div>
                                <label :for="'variant_color' + i" class="block text-sm font-medium text-gray-700">Variant Color</label>
                                <input @change="updateVariants()" type="text" :name="'variant_color' + i" :id="'variant_color' + i" autocomplete="title" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                              </div>

                              <div>
                                <label :for="'variant_size' + i" class="block text-sm font-medium text-gray-700">Variant Size</label>
                                <input @change="updateVariants()" type="text" :name="'variant_size' + i" :id="'variant_size' + i" autocomplete="title" class="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                              </div>

                          </div>
                      </template>

                      <input type="hidden" name="variants" :value="variants">

                      <div class="col-span-6 form-wrapper">
                          <button type="button" @click="count++" class="px-2 py-1 shadow-lg bg-gray-200">Add Variant +</button>
                      </div>

                      <div class="col-span-6 form-wrapper">
                          <button type="submit" class="px-2 py-1 shadow-lg bg-blue-500 text-white">Submit</button>
                      </div>
                       
                    </div>
                  </div>
                </div>
            </div>
          </div>
    </div>
    </form>

<div>
    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\machine\example-app\resources\views/addProduct.blade.php ENDPATH**/ ?>