<nav class="sm:col-span-2 min-h-screen">
    <div class="card rounded-none h-full border-r">
        <div class="px-8 py-4">
            <div class="my-4 flex items-center justify-center">
                <div class="text-blue-600">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-14 w-14" viewBox="0 0 20 20" fill="currentColor">
                      <path d="M5.5 16a3.5 3.5 0 01-.369-6.98 4 4 0 117.753-1.977A4.5 4.5 0 1113.5 16h-8z" />
                    </svg>
                </div>
                <div class="text-gray-600 font-black rounded-full bg-yellow-400" style="padding: 2px 7px; transform: rotate(-30deg) translate(-20px, -17px); transform-origin: top; font-size: 0.75rem;">
                    ₹
                </div>
                <div class="text-2xl text-gray-700 ml-0 -translate-x-2 mr-auto font-semibold">
                    dashboard
                </div>
            </div>
        </div>
        <div class="px-4 py-4">
            <ul class="list-none w-full">
                <li class="my-2">
                    <a href="<?php echo e(route('students')); ?>" class="nav-link <?php echo e(request()->routeIs('students') ? 'active' : ''); ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                          <path stroke-linecap="round" stroke-linejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                        </svg>
                        <span class="ml-4">Students</span>
                    </a>
                </li>
                <li class="my-2">
                    <a href="<?php echo e(route('addStudents')); ?>" class="nav-link <?php echo e(request()->routeIs('addStudents') ? 'active' : ''); ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                          <path stroke-linecap="round" stroke-linejoin="round" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
                        </svg>
                        <span class="ml-4">Add Students</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\machine\example-app\resources\views/parts/navigation.blade.php ENDPATH**/ ?>